%%clear all, clc, close all
%%load('')
yd = ST(:,2); %% respuesta del sistema de simulink
u = ST(:,1); %% Setpoint del sistema en simulink

k = 1:1:size(yd);
subplot(4,1,1);
plot(k,u,'r',k,yd,'b');
hold on 

%% Diagramas de autocorrelaci�n 
N = size(yd,1)-1;
subplot(4,1,2);
autocorr(yd,N);
subplot(4,1,3);
parcorr(yd,100);
%% Matriz de simulaci�n
data= iddata(yd,u,0.01); %%Matriz de simulaci�n (salida sistema, entrada sistema, periodo de muestreo usado)

%% Modelo autorregresivo con entrada ex�gena (ARX)
% yarx = arx(data,[4,1,0]) %%[na nb nk] Na=retrasos de la salida del sistema, Nb=retrasos del setpoint, Nk= retrasos del sistema 
% ys1=idsim(u,yarx); %% simulamos el modelo ARX, se le ingresa setpoint al modelo ARX
% subplot(4,1,4);
% plot(k,yd,'r',k,ys1,'b');

%% Modelo medias m�viles con entrada ex�gena (MAX)
% ymax = armax(data,[0,1,4,0]) %% Na, Nb, Nc, Nk (Nc= retrasos del error)
% ys2= idsim(u,ymax);
% subplot(4,1,4);
% plot(k,yd,'r',k,ys2,'b');

%% Modelo ARMAX 
yarmax = armax(data,[2,1,2,0])
ys3= idsim(u,yarmax);
subplot(4,1,4);
plot(k,yd,'b',k,ys3,'r');

